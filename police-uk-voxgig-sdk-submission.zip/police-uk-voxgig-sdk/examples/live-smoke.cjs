const assert = require('node:assert/strict');
const { PoliceUkSDK } = require('../ts/dist/PoliceUkSDK.js');
(async () => {
  const client = new PoliceUkSDK();
  const forces = await client.Force().list();
  assert.ok(Array.isArray(forces) && forces.length > 0);
  const first = forces[0].data();
  assert.equal(typeof first.id, 'string');
  assert.equal(typeof first.name, 'string');
  const force = await client.Force().load({ id: 'leicestershire' });
  assert.equal(force.data().id, 'leicestershire');
  console.log(JSON.stringify({ listCount: forces.length, loaded: force.data().name }));
  await assert.rejects(client.Force().load({ id: 'definitely-not-a-real-force-xyz' }));
  console.log('PASS: list, load, and unknown-force rejection');
})().catch(err => { console.error(err); process.exitCode = 1; });
