const {test} = require('node:test');
const assert = require('node:assert/strict');
const {PoliceUkSDK} = require('../ts/dist/PoliceUkSDK.js');
const make = (handler) => new PoliceUkSDK({system: {fetch: handler}});
test('list uses documented endpoint and maps records into entities', async () => {
 let request;
 const client = make(async (url, options) => { request = {url, options}; return new Response(JSON.stringify([{id:'leicestershire',name:'Leicestershire Police'}]), {status:200,headers:{'content-type':'application/json'}}); });
 const records = await client.Force().list();
 assert.equal(request.url, 'https://data.police.uk/api/forces');
 assert.equal(request.options.method, 'GET');
 assert.equal(records[0].data().id, 'leicestershire');
});
test('load uses path ID without duplicating it as a query parameter', async () => {
 let request;
 const client = make(async url => {request=url;return new Response(JSON.stringify({id:'leicestershire',name:'Leicestershire Police'}), {status:200});});
 const record=await client.Force().load({id:'leicestershire'});
 assert.equal(request, 'https://data.police.uk/api/forces/leicestershire');
 assert.equal(record.data().name, 'Leicestershire Police');
});
test('404 rejects rather than returning a successful force', async () => {
 const client=make(async () => new Response('{}',{status:404}));
 await assert.rejects(client.Force().load({id:'unknown-force'}));
});
test('transport errors reject', async () => {
 const client=make(async () => {throw new Error('offline test network failure')});
 await assert.rejects(client.Force().list());
});
