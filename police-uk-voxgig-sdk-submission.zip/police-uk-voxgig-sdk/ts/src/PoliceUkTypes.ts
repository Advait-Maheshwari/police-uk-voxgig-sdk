// Typed models for the PoliceUk SDK.
//
// GENERATED from the API model: main.kit.entity.<e>.fields{} and per-op
// params (op.<name>.points[].g.params[]). Field/param types come from the
// canonical type sentinels via @voxgig/sdkgen canonToType (source of truth:
// @voxgig/apidef VALID_CANON). Do not edit by hand.

export interface Force {
  description?: string
  id: string
  name: string
  telephone?: string
  url?: string
}

export interface ForceLoadMatch {
  id: string
}

export interface ForceListMatch {
  description?: string
  id?: string
  name?: string
  telephone?: string
  url?: string
}

