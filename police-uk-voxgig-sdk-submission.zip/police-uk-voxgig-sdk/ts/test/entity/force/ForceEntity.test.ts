

import Path from 'node:path'
import * as Fs from 'node:fs'

import { test, describe, afterEach } from 'node:test'
import assert from 'node:assert'
import { createLiveTransport } from '../../live-runner'
import { runLiveEntity } from '../../live-entity'


import { PoliceUkSDK, BaseFeature, config, stdutil } from '../../..'

import {
  envOverride,
  liveClientOptions,
  liveDelay,
  loadEnvLocal,
  makeCtrl,
  makeMatch,
  makeReqdata,
  makeStepData,
  makeValid,
  maybeSkipControl,
} from '../../utility'


loadEnvLocal(__dirname + '/../../../.env.local')


describe('ForceEntity', async () => {

  // Per-test live pacing. Delay is read from sdk-test-control.json's
  // `test.live.delayMs`; only sleeps when POLICE_UK_TEST_LIVE=TRUE.
  afterEach(liveDelay('POLICE_UK_TEST_LIVE'))

  test('instance', async () => {
    const testsdk = PoliceUkSDK.test()
    const ent = testsdk.Force()
    assert(null != ent)
  })


  class FailHook extends BaseFeature {
    name = 'failhook'
    version = '0.0.1'
    active = true
    unexpected = 0
    init() { }
    PreSpec() { throw new Error('force hook failed') }
    PreUnexpected() { this.unexpected++ }
  }

  test('stream-error', async () => {
    const offline = { net: { offline: true } }
    await assert.rejects(async () => {
      for await (const _item of PoliceUkSDK.test(offline).Force().stream('list')) { }
    }, /offline/)

    for await (const _item of PoliceUkSDK.test(offline).Force()
      .stream('list', undefined, { ctrl: { throw: false } })) { }

    if (null != (config as any).feature?.rbac) {
      const denied = PoliceUkSDK.test(undefined, { feature: { rbac: { active: true, deny: true } } })
      await assert.rejects(async () => {
        for await (const _item of denied.Force().stream('list')) { }
      }, (err: any) => 'rbac_denied' === err.code)
    }
  })

  test('stream-ctrl', async () => {
    const explain: any = {}
    const ctrl: any = { explain }
    for await (const _item of PoliceUkSDK.test().Force().stream('list', undefined, { ctrl })) { }
    assert.deepStrictEqual(Object.keys(ctrl), ['explain'])
    assert(explain === ctrl.explain && 0 < Object.keys(explain).length)
  })

  test('unexpected', async () => {
    const hook = new FailHook()
    const client = new PoliceUkSDK({ feature: { test: { active: true } }, extend: [hook] })
    await assert.rejects(client.Force().list(), /hook failed/)
    assert(0 < hook.unexpected)

    const fired = hook.unexpected
    assert.strictEqual(await client.Force().list(undefined, { throw: false }), undefined)
    assert(fired < hook.unexpected)
  })

  test('validate', async (t) => {
    if (null == (config as any).feature?.validate) {
      t.skip('feature not present in this SDK: validate')
      return
    }
    const client = PoliceUkSDK.test(undefined, { feature: { validate: { active: true } } })
    await assert.rejects(client.Force().list({"description":1} as any),
      (err: any) => 'validate_failed' === err.code)
  })



  test('basic', async (t) => {

    const live = 'TRUE' === process.env.POLICE_UK_TEST_LIVE
    for (const op of ['list', 'load']) {
      if (!live && maybeSkipControl(t, 'entityOp', 'force.' + op, live)) return
    }

    
    const setup = basicSetup()
    if (setup.live) {
      return runLiveEntity(setup, {"active":true,"alias":{"field":{}},"fields":{"description":{"a":true,"h":"Description","n":"description","r":false,"t":"`$STRING`","key$":"description","index$":0},"id":{"a":true,"h":"Id","n":"id","r":true,"t":"`$STRING`","key$":"id","index$":1},"name":{"a":true,"h":"Name","n":"name","r":true,"t":"`$STRING`","key$":"name","index$":2},"telephone":{"a":true,"h":"Telephone","n":"telephone","r":false,"t":"`$STRING`","key$":"telephone","index$":3},"url":{"a":true,"h":"Url","n":"url","r":false,"t":"`$STRING`","key$":"url","index$":4}},"id":{"field":"id","name":"id"},"name":"force","op":{"list":{"input":"data","name":"list","points":[{"a":true,"co":{"id":"GET /forces","source":"openapi3","version":2},"g":{},"k":"http","m":"GET","o":"/forces","q":{},"r":{},"rs":{"kind":"json","media":"application/json"},"s":[{"lit":"forces"}],"t":{"req":"`reqdata`","res":"`body`"},"index$":0}],"key$":"list"},"load":{"input":"data","name":"load","points":[{"a":true,"co":{"id":"GET /forces/{id}","source":"openapi3","version":2},"g":{"params":[{"a":true,"ex":"leicestershire","k":"param","n":"id","or":"id","r":true,"t":"`$STRING`","index$":0}]},"k":"http","m":"GET","o":"/forces/{id}","q":{"exist":["id"]},"r":{},"rs":{"kind":"json","media":"application/json"},"s":[{"lit":"forces"},{"var":"id"}],"t":{"req":"`reqdata`","res":"`body`"},"index$":0}],"key$":"load"}},"relations":{"ancestors":[]},"key$":"force","name__orig":"force","Name":"Force","name_":"force","name-":"force","NAME":"FORCE","index$":0}, {"active":true,"entity":"force","key$":"BasicForceFlow","kind":"basic","name":"BasicForceFlow","param":{},"step":[{"a":true,"d":{},"i":{},"m":{},"o":"list","s":[],"v":[{"apply":"ItemExists","def":{"ref":"force_ref01"}}]},{"a":true,"d":{},"i":{"ref":"force_ref01","srcdatavar":"force_ref01_data","suffix":"_dt0"},"m":{"id":"force01"},"o":"load","s":[],"v":[{"apply":"TextFieldMark","def":{"mark":"Mark01-force_ref01"}}]}]}, 'Force', {"GET /forces":{"protocol":"http","parameters":[]},"GET /forces/{id}":{"protocol":"http","parameters":[{"name":"id","in":"path","required":true,"schema":{"type":"string"},"example":"leicestershire","index$":0}]}}, { strict: LIVE_STRICT, t })
    }
    const client = setup.client
    const struct = setup.struct

    const isempty = struct.isempty
    const select = struct.select

    let force_ref01_data = Object.values(setup.data.existing.force)[0] as any

    // LIST
    const force_ref01_ent = client.Force()
    const force_ref01_match: any = {}

    const force_ref01_list = (await force_ref01_ent.list(force_ref01_match)).map((e: any) => e.data())


    // LOAD
    const force_ref01_match_dt0: any = {}
    force_ref01_match_dt0.id = force_ref01_data.id
    const force_ref01_data_dt0 = (await force_ref01_ent.load(force_ref01_match_dt0)).data()
    assert(force_ref01_data_dt0.id === force_ref01_data.id)


  })
})



// main.kit.test.live.strict is true (the default is true): a live
// request that fails, or a live test missing an input it needs,
// fails the test.
// An account with no record for a test to read skips it either way.
const LIVE_STRICT = true

function basicSetup(extra?: any) {
  // TODO: fix test def options
  const options: any = {} // null

  // TODO: needs test utility to resolve path
  const entityDataFile =
    Path.resolve(__dirname, 
      '../../../../.sdk/test/entity/force/ForceTestData.json')

  // TODO: file ready util needed?
  const entityDataSource = Fs.readFileSync(entityDataFile).toString('utf8')

  // TODO: need a xlang JSON parse utility in voxgig/struct with better error msgs
  const entityData = JSON.parse(entityDataSource)

  options.entity = entityData.existing

  let client = PoliceUkSDK.test(options, extra)
  const struct = client.utility().struct
  const merge = struct.merge
  const transform = struct.transform

  let idmap = transform(
    ['force01','force02','force03'],
    {
      '`$PACK`': ['', {
        '`$KEY`': '`$COPY`',
        '`$VAL`': ['`$FORMAT`', 'upper', '`$COPY`']
      }]
    })

  const env = envOverride({
    'POLICE_UK_TEST_FORCE_ENTID': idmap,
    'POLICE_UK_TEST_LIVE': 'FALSE',
    'POLICE_UK_TEST_EXPLAIN': 'FALSE',
  })

  idmap = env['POLICE_UK_TEST_FORCE_ENTID']

  const live = 'TRUE' === env.POLICE_UK_TEST_LIVE

  const transport = createLiveTransport()
  if (live) {
    const rawIds = process.env['POLICE_UK_TEST_FORCE_ENTID']
    idmap = rawIds && rawIds.trim() ? JSON.parse(rawIds) : {}
    if (!idmap || Array.isArray(idmap) || typeof idmap !== 'object') {
      throw new Error('Live ENTID must be a JSON object')
    }
    client = new PoliceUkSDK(merge([
      // FIRST, so the generated fields below win: sdk-test-control.json's
      // test.client.options adds to the live client, it does not redirect it.
      liveClientOptions(),
      {
      },
      // 'extra || {}', not a bare 'extra': struct.merge returns UNDEFINED when the
      // last entry is undefined, and basicSetup is normally called with no
      // argument at all - so a bare 'extra' silently discarded the apikey
      // and server values above and handed the SDK undefined. Harmless
      // while there was nothing in that object; not harmless now.
      extra || {},
      { system: { fetch: transport.fetch } }
    ]))
  }

  const setup = {
    idmap,
    env,
    options,
    client,
    struct,
    data: entityData,
    explain: 'TRUE' === env.POLICE_UK_TEST_EXPLAIN,
    live,
    transport,
    now: Date.now(),
  }

  return setup
}
  
