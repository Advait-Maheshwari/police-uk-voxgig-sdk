
import { test, describe } from 'node:test'
import { equal } from 'node:assert'


import { PoliceUkSDK } from '..'


describe('exists', async () => {

  test('test-mode', () => {
    const testsdk = PoliceUkSDK.test()
    equal(testsdk instanceof PoliceUkSDK, true,
      'PoliceUkSDK.test() must return a client synchronously')
  })

})
