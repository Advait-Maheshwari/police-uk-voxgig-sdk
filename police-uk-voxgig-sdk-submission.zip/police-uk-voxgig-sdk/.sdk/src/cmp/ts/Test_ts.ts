
import type {
  ModelEntity
} from '@voxgig/apidef'

import { cmp, each, Folder, entityCollection,
  TestControl } from '@voxgig/sdkgen'


import { TestLive } from './TestLive_ts'
import { TestDefinition } from './TestDefinition_ts'
import { TestClean } from './TestClean_ts'
import { TestDirect } from './TestDirect_ts'
import { TestEntity } from './TestEntity_ts'
import { ReadmeExampleTest } from './ReadmeExampleTest_ts'
import { ReadmeExamplesTest } from './ReadmeExamplesTest_ts'


const Test = cmp(function Test(props: any) {
  const { model, stdrep } = props.ctx$
  const { target } = props

  Folder({ name: 'test' }, () => {

    // Write-once: a project's edited control file survives regeneration.
    TestControl({ target, dir: 'test' })
    TestLive({ target })
    TestDefinition({ target })
    TestClean({ target })

    ReadmeExampleTest({ target })
    ReadmeExamplesTest({ target })

    Folder({ name: 'entity' }, () => {
      // entityCollection is the cached, UNFILTERED collection (AGENTS.md), so
      // the active filter the raw model read this replaced never applied is
      // written out here. Tests follow Main: an inactive entity has no source.
      const entity = each(entityCollection(model))
        .filter((e: any) => false !== e.active)

      each(entity, (entity: ModelEntity) => {
        TestEntity({ target, entity })
        TestDirect({ target, entity })
      })
    })
  })
})


export {
  Test
}
